describe('Login Page',function(){
	it('check login functionality', function(){
		browser.get('http://localhost:4200');
			element(by.id('register')).click()
			expect(browser.getCurrentUrl()).toBe('http://localhost:4200/register');			
	});
});
	