describe('Member profile',function(){
	it('check profile functionality', function(){
		browser.get('http://localhost:4200');
			element(by.id('register')).click();
			element(by.name('name')).sendKeys('Names');
			element(by.name('username')).sendKeys('users');
			element(by.name('pwd')).sendKeys('users');
			element(by.name('role')).sendKeys('Member');
			element(by.name('guardiantype')).sendKeys('Father');
			element(by.name('guardianname')).sendKeys('Name');
			element(by.name('address')).sendKeys('address');
			element(by.name('citizenship')).sendKeys('indian');
			element(by.name('state')).sendKeys('Tamilnadu');
			element(by.name('country')).sendKeys('India');
			element(by.name('email')).sendKeys('sdfs@gmail.com');
			element(by.id('male')).click();
			element(by.id('married')).click();
			element(by.name('contactno')).sendKeys('9896767890');
			element(by.name('dob')).sendKeys('1998-09-09');
			element(by.id('current')).click();
			element(by.id('citizen')).click();
			element(by.name('branchname')).sendKeys('ramnagar');
			element(by.id('registersubmit')).click();
			element(by.id('clicklogin')).click();
			element(by.name('username')).sendKeys('users');
			element(by.name('pwd')).sendKeys('users');
			element(by.id('gotest')).click();
			element(by.id('profile')).click();
			browser.waitForAngularEnabled(false);
			expect(browser.getCurrentUrl()).toBe('http://localhost:4200/profile');
	});
});
	