describe('Login Page',function(){
	it('check login functionality', function(){
		browser.get('http://localhost:4200');
		element(by.name('username')).sendKeys('10');
		element(by.name('pwd')).sendKeys('100');
			element(by.id('gotest')).click();
			expect(element(by.id('message')).isDisplayed()).toBe(true);
	});
});
	