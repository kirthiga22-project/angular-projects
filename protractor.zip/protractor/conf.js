exports.config ={
	seleniumAddress:'http://localhost:4444/wd/hub',
	specs:['InvalidLogin-spec.js','RegisterCheck-spec.js','MemberRegister-spec.js','MemberNewClaim-spec.js','AdjudicatorRegister-spec.js','AdjudicatorViewclaim-spec.js','AdjudicatorApproveClaim-spec.js','MemberProfile-spec.js']	
}