export class User {
    name: string;
    username: string;
    password: string;
    role: string;
    guardiantype: string;
    guardianname: string;
    address: string;
    citizenship: string;
    state: string;
    country: string;
    email: string;
    gender: string;
    marital: string;
    contactno: string;
    dob: string;
    registrationdate: string;
    accounttype: string;
    branchname: string;
    citizenstatus: string;
    photo: string;
}