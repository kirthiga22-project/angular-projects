export class Claim {
    id: number;
    patientname: string;
    dob: string;
    admissiondate: string;
    dischargedate: string;
    hospitalname: string;
    hospitaladdress: string;
    claimamount: string;
    contactno: string;
    bill: String;
    status: string;
    username: string;
    comments: string;
}