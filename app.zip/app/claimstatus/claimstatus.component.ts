import { Component, OnInit } from '@angular/core';
import { Claim } from '../models/claim';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticateService } from '../services/authenticate.service';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { User } from '../models/user';
import { ThisReceiver } from '@angular/compiler';

@Component({
  selector: 'app-claimstatus',
  templateUrl: './claimstatus.component.html',
  styleUrls: ['./claimstatus.component.css']
})
export class ClaimstatusComponent implements OnInit {
  claimStatusForm: FormGroup;
  claimJson: any;
  claimObject: any;
  currentClaim: Claim;
  currentUser: User;
  updatedClaim: Claim;
  claimsList: Claim[];
  id: number;
  constructor(
    private route: Router,
    private authenticateService: AuthenticateService,
    private claimFormBuilder: FormBuilder,
    private claimStatusFormBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute
  ) {

  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.id = +params['id'];
    });
    this.claimsList = JSON.parse(sessionStorage.getItem('claims'));
    this.currentClaim = this.claimsList.filter(claim => claim.id == this.id)[0];
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.claimStatusForm = this.claimStatusFormBuilder.group({
      claimstatus: ['', Validators.required]
    });
  }

  get f() {
    return this.claimStatusForm.controls;
  }
  onClaimStatusSubmit() {
    this.currentClaim.status = this.f.claimstatus.value;
    this.claimsList.forEach((item, index) => {
      if (item.id == this.currentClaim.id) this.claimsList.splice(index, 1);
    });
    this.claimsList.push(this.currentClaim);
    sessionStorage.setItem('claims', JSON.stringify(this.claimsList));
    this.route.navigate(['/dashboard']);
  }

  updateClaimStatus(value){
    this.currentClaim.status=value;
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.claimsList.forEach((item, index) => {
      if (item.id == this.currentClaim.id) this.claimsList.splice(index, 1);
    });
    this.claimsList.push(this.currentClaim);
    sessionStorage.setItem('claims', JSON.stringify(this.claimsList));
    this.route.navigate(['/dashboard']);
  }

  logout() {
    sessionStorage.clear();
    this.route.navigate(['/']);
  }


}


