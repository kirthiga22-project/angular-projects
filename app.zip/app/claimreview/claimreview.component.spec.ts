import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimreviewComponent } from './claimreview.component';

describe('ClaimreviewComponent', () => {
  let component: ClaimreviewComponent;
  let fixture: ComponentFixture<ClaimreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimreviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
