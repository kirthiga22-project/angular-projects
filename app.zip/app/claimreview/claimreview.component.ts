import { Component, OnInit, Input, EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-claimreview',
  templateUrl: './claimreview.component.html',
  styleUrls: ['./claimreview.component.css']
})
export class ClaimreviewComponent implements OnInit {

  @Input() claimStatus :string;
  @Output() newClaimStatusEvent= new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
    
  }
  modifyClaimStatus(value:string){
    this.newClaimStatusEvent.emit(value);
  }
}
