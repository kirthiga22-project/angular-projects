import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, AbstractControl, Validators, ValidatorFn, FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { User } from '../models/user';
import { UserService } from '../services/user.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  base64;
  registerLoading = false;
  registerSubmitted = false;
  returnUrl: string;
  error: string;
  success: string;
  registerShowMsg: boolean = false;
  fileUrl: File;
  currentDateValue = new Date();
  currentDate = new Date().toISOString().slice(0, 10);
  maxDob = new Date(this.currentDateValue.getFullYear() - 18, this.currentDateValue.getMonth(), this.currentDateValue.getDate()).toISOString().slice(0, 10);
  minDob = new Date(this.currentDateValue.getFullYear() - 96, this.currentDateValue.getMonth(), this.currentDateValue.getDate()).toISOString().slice(0, 10);
  constructor(
    private route: Router,
    private registerFormBuilder: FormBuilder,
    private userService: UserService
  ) {

  }

  ngOnInit(): void {
    this.registerForm = this.registerFormBuilder.group({
      name: ['', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+[a-zA-Z]$')]],
      username: ['', [Validators.required, Validators.pattern('[a-zA-Z][a-zA-Z ]+[a-zA-Z]$')]],
      password: ['', Validators.required],
      role: ['', Validators.required],
      guardiantype: ['', Validators.required],
      guardianname: ['', Validators.required],
      address: ['', Validators.required],
      citizenship: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      gender: ['', Validators.required],
      marital: ['', Validators.required],
      contactno: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      dob: ['', Validators.required],
      registrationdate: new FormControl((new Date()).toISOString().substring(0, 10)),
      accounttype: ['', Validators.required],
      citizenstatus: ['', Validators.required],
      branchname: ['', Validators.required],
      photo: ['photo', Validators.required]
    });

  }


  getToday(): string {
    return new Date().toISOString().split['T'][0];
  }

  get f() {
    return this.registerForm.controls;
  }
  onRegisterSubmit() {
    this.registerSubmitted = true;
    if (!(this.registerForm.invalid)) {
      this.registerShowMsg = true;
      this.userService.register(this.registerForm.value, this.base64);
      this.registerForm.reset();
      this.registerSubmitted = false;
    } else {
      return;
    }
  }

  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    var file: File = inputValue.files[0];
    var myReader: FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.base64 = myReader.result;
    }
    myReader.readAsDataURL(file);

  }
}

