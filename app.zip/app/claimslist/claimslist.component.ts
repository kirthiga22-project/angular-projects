import { Component, OnInit } from '@angular/core';
import { Claim } from '../models/claim';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticateService } from '../services/authenticate.service';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { User } from '../models/user';

@Component({
  selector: 'app-claimslist',
  templateUrl: './claimslist.component.html',
  styleUrls: ['./claimslist.component.css']
})
export class ClaimslistComponent implements OnInit {

  claimsList: Claim[];
  claimsUserList: Claim[];
  currentUser: User;
  constructor(
    private route: Router
  ) {

  }

  ngOnInit(): void {
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    this.claimsList = JSON.parse(sessionStorage.getItem('claims'));
    if (this.currentUser.role == 'member') {
      this.claimsUserList = this.claimsList.filter(claim => claim.username == this.currentUser.username);
    } else {
      this.claimsUserList = this.claimsList.filter(claim => claim.status == 'Review In progress');
    }
  }
  logout() {
    sessionStorage.clear();
    this.route.navigate(['/']);
  }
}
