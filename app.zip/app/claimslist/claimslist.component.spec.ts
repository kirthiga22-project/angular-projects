import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimslistComponent } from './claimslist.component';

describe('ClaimslistComponent', () => {
  let component: ClaimslistComponent;
  let fixture: ComponentFixture<ClaimslistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimslistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
