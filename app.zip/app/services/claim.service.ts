import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Claim } from '../models/claim';
import { User } from '../models/user';
import { AuthenticateService } from '../services/authenticate.service';


@Injectable({
  providedIn: 'root'
})


export class ClaimService {
  currentUser: User;
  claimJson: string;
  claimObject: Claim;
  claimsList: Array<Claim> = [];

  constructor(
    private route: Router,
    private authenticateService: AuthenticateService

  ) { }

  submitclaim(claim: Claim, isAddMode: boolean, id: number, base64) {
    claim.status = 'Review In progress';
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    claim.username = this.currentUser.username;
    this.claimsList = JSON.parse(sessionStorage.getItem('claims'));
    if (isAddMode) {
      if (this.claimsList == null) {
        claim.id = 1;
      } else {
        claim.id = this.claimsList.length + 1;
      }
    } else {
      claim.id = id;
    }
    claim.bill = base64;
    this.claimJson = JSON.stringify(claim);
    this.claimObject = JSON.parse(this.claimJson);

    if (null == this.claimsList) {
      this.claimsList = Array(this.claimObject);
    } else {
      if (isAddMode) {
        this.claimsList.push(this.claimObject);
      } else {
        this.claimsList.forEach((item, index) => {
          if (item.id == id) this.claimsList.splice(index, 1);
        });
        this.claimsList.push(this.claimObject);
      }
    }
    sessionStorage.setItem('claims', JSON.stringify(this.claimsList));

  }
}

