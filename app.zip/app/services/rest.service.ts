import { Injectable } from '@angular/core';
import { Observable, throwError } from "rxjs";
import { HttpClient, HttpHeaders, HttpRequest, HttpErrorResponse, HttpResponse } from "@angular/common/http";

import { catchError, map } from "rxjs/operators";
import { User } from "../models/user";
const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST"
  })
}

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(private http: HttpClient) { }

  private handleError(error: HttpErrorResponse) {

    if (error.error instanceof ErrorEvent) {
      return throwError(error);
    }
  }
  private extractData(res: Response) {
    let body = res;
    return body || {};
  }

  public getListOfGroup(url: string):Observable<User> {
    return this.http.get<User>(url, httpOptions);
  }

}