import { Injectable } from '@angular/core';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  register(user: User, base64) {
    user.photo = base64;
    sessionStorage.setItem(user.username, JSON.stringify(user));
  }

}
