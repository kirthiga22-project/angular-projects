import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { throwError } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {
  userJson: any;
  userObject: any;
  constructor(
    private route: Router
  ) {

  }

  authenticate(username: string, password: string) {
    this.userJson = sessionStorage.getItem(username);
    this.userObject = JSON.parse(this.userJson);
    if (this.userObject.username == username && this.userObject.password == password) {
      sessionStorage.setItem('currentUser', JSON.stringify(this.userObject));
      this.route.navigate(['/dashboard']);
    } else {
      return this.userObject;
    }
  }
}
