import { Component, OnInit, Injectable, Inject } from '@angular/core';
import { User } from '../models/user';
import { Router, ActivatedRoute } from '@angular/router';
import { RestService } from "../services/rest.service";
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {
  currentUser: User;
  userResponse :User;
  url = "http://localhost:8081/status";
  constructor(
    private route: Router,
    private api: RestService

  ) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

   this.api.getListOfGroup(this.url).subscribe((user:User)=>{
     this.currentUser=user;
   });
   
  }



  logout() {
    sessionStorage.clear();
    this.route.navigate(['/']);
  }


}
